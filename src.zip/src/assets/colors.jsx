/* eslint-disable react-refresh/only-export-components */
const RED = "#a6192e";
const GOLD = "#eaaa00";
const GREEN = "#154734";
const WHEAT = "#DDCBA4";

const WATER_BLUE = "#568BC4";
const OAK_GREEN = "#697337";
const SUNSET_ORANGE = "#D45A63";

export { RED, GOLD, GREEN, WHEAT, WATER_BLUE, OAK_GREEN, SUNSET_ORANGE };
