const LeftAside = () => <aside></aside>;

const CenterSection = () => <section></section>;

const RightAside = () => <aside></aside>;

const Template = () => (
  <>
    <LeftAside />
    <CenterSection />
    <RightAside />
  </>
);

// export default Template;
