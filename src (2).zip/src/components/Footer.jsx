const Footer = () => (
  <footer>Made by Joe P. Shoulak - {new Date().getFullYear()}</footer>
);

export { Footer };
